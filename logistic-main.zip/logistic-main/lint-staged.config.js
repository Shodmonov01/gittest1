module.exports = {
  "*.{js,jsx,vue,ts,tsx}": "vue-cli-service lint",
};
