<template>
    <div class="nav-bar-info">
    <ul >
       <li>Общее</li>
       <li>Товары списания</li>
       <li>Доп. Расходы</li>

    </ul>

        <img src="../../assets/img/gear.svg" alt="">
    </div>
</template>

<script>
    export default {

    }
</script>

<style scoped lang="scss">
@import "NavBarInfo";
</style>